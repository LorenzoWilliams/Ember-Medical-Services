CREATE VIEW [Female_Patients] AS
SELECT *
FROM Patients
WHERE Gender = 'F';




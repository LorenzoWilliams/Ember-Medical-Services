use Ember_medical_service_db;

delete from  Patients  
WHERE id = 8; 
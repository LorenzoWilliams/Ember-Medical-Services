use Ember_medical_service_db;

update Patients set Email='Lorenzo_1williams@hotmail.com'
where id = '1';
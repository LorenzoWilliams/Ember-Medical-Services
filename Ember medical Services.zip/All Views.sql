use Ember_medical_service_db;

select * from dbo.[Paid_Patient];
select * from dbo.[Female_Patients];
select * from dbo.[Appointment_View];
select * from dbo.[Nurses_Patient_View];
select * from dbo.[staff_members];
select * from dbo.[Patients_address];


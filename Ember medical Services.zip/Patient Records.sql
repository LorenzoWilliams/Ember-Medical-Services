use Ember_medical_service_db;

select * from Patients;

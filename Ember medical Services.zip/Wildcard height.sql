use Ember_medical_service_db

select * from Visits
where Height_cm like '17%';
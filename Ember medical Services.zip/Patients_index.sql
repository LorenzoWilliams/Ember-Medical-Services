CREATE INDEX idx_lastname
ON Patients (LastName);



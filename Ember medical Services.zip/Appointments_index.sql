CREATE INDEX idx_Appointments
ON Appointments (Patient_id);


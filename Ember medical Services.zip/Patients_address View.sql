Create view Patients_address as
select LastName, FirstName, Address
from Patients;
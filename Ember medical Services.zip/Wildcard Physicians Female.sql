use Ember_medical_service_db;

select * from Physicians
where gender not like 'm'
use Ember_medical_service_db;

select * from Physicians
where gender = 'M' and Last_Name like 'A%'
use Ember_medical_service_db

select * from Physicians
where Postion like 'Gen%';